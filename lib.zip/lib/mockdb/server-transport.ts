import { createMockClient, type Transport } from "./client";
import { handleAuth } from "./auth";
import { execute } from "./execute";
import { fileKey, store } from "./store";

/** Runs straight against the in-memory store. Used by server code and API routes. */
export const serverTransport: Transport = {
  async query(descriptor) {
    return execute(descriptor);
  },

  async auth(method, args) {
    return handleAuth(method, args);
  },

  async upload(bucket, path, file, options) {
    const data =
      file instanceof Uint8Array ? file : new Uint8Array(await (file as Blob).arrayBuffer());
    const contentType =
      options?.contentType || (file as Blob).type || "application/octet-stream";

    store.files.set(fileKey(bucket, path), { data, contentType });
    return { data: { path }, error: null };
  },

  async remove(bucket, paths) {
    for (const path of paths) store.files.delete(fileKey(bucket, path));
    return { data: [], error: null };
  },

  origin() {
    return (
      process.env.NEXT_PUBLIC_APP_URL || `http://localhost:${process.env.PORT || 3000}`
    ).replace(/\/$/, "");
  },
};

export function createServerMockClient() {
  return createMockClient(serverTransport);
}
