/**
 * Prototype storage: one in-memory "database" for the whole server process.
 *
 * - Lives on globalThis so it survives hot reloads in `next dev`.
 * - Starts empty and is wiped whenever the server restarts.
 * - There is one built-in local user and no sign-in.
 */

export type Row = Record<string, any>;

type StoredFile = { data: Uint8Array; contentType: string };

type Store = {
  tables: Map<string, Row[]>;
  files: Map<string, StoredFile>;
  userMetadata: Record<string, any>;
};

const globalForStore = globalThis as unknown as { __auditflowStore?: Store };

export const store: Store = (globalForStore.__auditflowStore ??= {
  tables: new Map(),
  files: new Map(),
  userMetadata: { full_name: "Local User", workspace_name: "AuditFlow Workspace" },
});

export const LOCAL_USER_ID = "00000000-0000-4000-8000-000000000001";
export const LOCAL_USER_EMAIL = "you@auditflow.local";

export function getLocalUser() {
  return {
    id: LOCAL_USER_ID,
    email: LOCAL_USER_EMAIL,
    aud: "authenticated",
    role: "authenticated",
    app_metadata: {},
    user_metadata: { ...store.userMetadata },
    identities: [{ id: LOCAL_USER_ID }],
    created_at: "2026-01-01T00:00:00.000Z",
  };
}

export function getTable(name: string): Row[] {
  let rows = store.tables.get(name);

  if (!rows) {
    rows = [];
    store.tables.set(name, rows);
  }

  return rows;
}

export function fileKey(bucket: string, path: string) {
  return `${bucket}/${path}`;
}
