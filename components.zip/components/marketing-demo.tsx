"use client";

import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  BarChart3,
  Bell,
  CheckCircle2,
  Download,
  FileText,
  FolderKanban,
  GitBranch,
  Lightbulb,
  MessageSquare,
  MousePointer2,
  Search,
  ShieldCheck,
} from "lucide-react";

type SceneId =
  | "landing"
  | "dashboard"
  | "createProject"
  | "findings"
  | "journeys"
  | "recommendations"
  | "reports"
  | "portal"
  | "ending";

type Scene = {
  id: SceneId;
  eyebrow: string;
  title: string;
  description: string;
  duration: number;
  cursor: { left: string; top: string };
  zoom?: string;
  script: string;
};

const scenes: Scene[] = [
  {
    id: "landing",
    eyebrow: "0:00 — Hook",
    title: "UX audits deserve a better workflow.",
    description: "Start with the promise, not a feature tour.",
    duration: 5200,
    cursor: { left: "72%", top: "56%" },
    zoom: "scale-[1.01]",
    script:
      "UX audits shouldn’t live in spreadsheets, screenshots, and scattered documents.",
  },
  {
    id: "dashboard",
    eyebrow: "0:05 — Workspace",
    title: "One place for the full audit lifecycle.",
    description: "Show the dashboard as the operating system for audit work.",
    duration: 6200,
    cursor: { left: "82%", top: "18%" },
    zoom: "scale-[1.015]",
    script:
      "AuditFlow brings your entire UX audit workflow into one focused workspace.",
  },
  {
    id: "createProject",
    eyebrow: "0:11 — Project setup",
    title: "Create a project in seconds.",
    description: "Use clean fictional demo data and a focused setup screen.",
    duration: 6500,
    cursor: { left: "67%", top: "82%" },
    zoom: "scale-[1.02]",
    script:
      "Create a project in seconds and start documenting issues immediately.",
  },
  {
    id: "findings",
    eyebrow: "0:18 — Findings",
    title: "Capture, search, sort, and prioritize.",
    description: "Highlight the improved search and sorting behavior.",
    duration: 7800,
    cursor: { left: "78%", top: "37%" },
    zoom: "scale-[1.02]",
    script:
      "Capture findings, prioritize by severity, and keep every recommendation organized.",
  },
  {
    id: "journeys",
    eyebrow: "0:26 — Journeys",
    title: "Connect findings to the user journey.",
    description: "Make the audit feel connected instead of scattered.",
    duration: 6400,
    cursor: { left: "49%", top: "67%" },
    zoom: "scale-[1.015]",
    script:
      "Map issues directly to user journeys so every recommendation has context.",
  },
  {
    id: "recommendations",
    eyebrow: "0:32 — Recommendations",
    title: "Reuse your best advice.",
    description: "Show saved recommendations as a repeatable system.",
    duration: 5600,
    cursor: { left: "34%", top: "35%" },
    zoom: "scale-[1.015]",
    script:
      "Save your best recommendations and reuse them across future audits.",
  },
  {
    id: "reports",
    eyebrow: "0:38 — Reports",
    title: "Generate client-ready reports.",
    description: "Use the project Reports tab, then preview and export.",
    duration: 7000,
    cursor: { left: "78%", top: "78%" },
    zoom: "scale-[1.02]",
    script:
      "Generate polished, client-ready reports with just a few clicks.",
  },
  {
    id: "portal",
    eyebrow: "0:45 — Client Portal",
    title: "Collaborate without losing context.",
    description: "Show client comments, auditor replies, and portal notifications.",
    duration: 6800,
    cursor: { left: "70%", top: "55%" },
    zoom: "scale-[1.015]",
    script:
      "Share your work, collaborate with clients, and keep every conversation in one place.",
  },
  {
    id: "ending",
    eyebrow: "0:53 — Close",
    title: "AuditFlow. From insight to action.",
    description: "End cleanly on the brand and tagline.",
    duration: 5200,
    cursor: { left: "50%", top: "72%" },
    zoom: "scale-100",
    script:
      "Spend less time managing audits and more time improving products. AuditFlow. From insight to action.",
  },
];

export const marketingVoiceoverScript = scenes.map((scene) => scene.script);

export function MarketingDemo() {
  const [sceneIndex, setSceneIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isRecordingMode, setIsRecordingMode] = useState(false);
  const [isScriptOpen, setIsScriptOpen] = useState(true);
  const scene = scenes[sceneIndex];
  const progress = Math.round(((sceneIndex + 1) / scenes.length) * 100);

  useEffect(() => {
    if (!isPlaying) return;
    const timer = window.setTimeout(() => {
      setSceneIndex((index) => (index + 1) % scenes.length);
    }, scene.duration);
    return () => window.clearTimeout(timer);
  }, [isPlaying, scene.duration, sceneIndex]);

  const script = useMemo(() => scenes.map((item) => item.script).join("\n\n"), []);

  return (
    <div className={`min-h-screen bg-slate-950 text-white ${isRecordingMode ? "p-0" : "px-4 py-6 sm:px-6 lg:px-8"}`}>
      {!isRecordingMode ? (
        <div className="mx-auto flex max-w-[1500px] flex-col gap-4 pb-5 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-violet-300">
              AuditFlow marketing demo
            </p>
            <h1 className="mt-2 text-2xl font-semibold tracking-[-0.04em] sm:text-3xl">
              60-second product video sequence
            </h1>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setIsRecordingMode(true)}
              className="rounded-xl border border-violet-300/40 bg-violet-500/15 px-4 py-2 text-sm font-semibold text-violet-100 hover:bg-violet-500/25"
            >
              Recording Mode
            </button>
            <button
              type="button"
              onClick={() => setIsPlaying((value) => !value)}
              className="rounded-xl border border-white/15 bg-white/10 px-4 py-2 text-sm font-semibold text-white hover:bg-white/15"
            >
              {isPlaying ? "Pause" : "Play"}
            </button>
            <button
              type="button"
              onClick={() => {
                setSceneIndex(0);
                setIsPlaying(true);
              }}
              className="rounded-xl bg-violet-500 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-400"
            >
              Restart
            </button>
          </div>
        </div>
      ) : null}

      <div className={isRecordingMode ? "mx-auto h-screen w-screen bg-slate-950" : "mx-auto max-w-[1500px] space-y-6"}>
        <div className={`overflow-hidden border border-white/10 bg-slate-900 shadow-2xl shadow-violet-950/40 ${isRecordingMode ? "h-screen rounded-none border-0" : "rounded-[2rem]"}`}>
          {!isRecordingMode ? (
            <div className="flex h-11 items-center gap-2 border-b border-white/10 bg-slate-950/70 px-5">
              <span className="h-3 w-3 rounded-full bg-red-400" />
              <span className="h-3 w-3 rounded-full bg-yellow-400" />
              <span className="h-3 w-3 rounded-full bg-green-500" />
              <span className="ml-4 rounded-full bg-white/10 px-4 py-1.5 text-xs font-semibold text-slate-300">
                auditflowapp.co/marketing-demo
              </span>
              <span className="ml-auto text-xs font-semibold text-violet-200">
                {progress}%
              </span>
            </div>
          ) : null}

          <div className={`relative overflow-hidden bg-slate-100 ${isRecordingMode ? "h-screen" : "aspect-video min-h-[520px]"}`}>
            <div
              key={scene.id}
              className={`h-full origin-center transition-all duration-700 ease-out ${scene.zoom ?? "scale-100"}`}
            >
              <MarketingScreen scene={scene.id} />
            </div>

            <div className="pointer-events-none absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-white/30 to-transparent" />
            <Cursor left={scene.cursor.left} top={scene.cursor.top} />
            <div className="absolute bottom-6 left-6 right-6 rounded-3xl border border-white/60 bg-white/90 p-5 shadow-xl shadow-slate-900/10 backdrop-blur">
              <p className="text-xs font-semibold uppercase tracking-[0.18em] text-violet-600">
                {scene.eyebrow}
              </p>
              <h2 className="mt-2 text-2xl font-semibold tracking-[-0.04em] text-slate-950">
                {scene.title}
              </h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">
                {scene.description}
              </p>
            </div>

            {isRecordingMode ? (
              <button
                type="button"
                onClick={() => setIsRecordingMode(false)}
                className="absolute right-5 top-5 rounded-full border border-white/20 bg-slate-950/70 px-4 py-2 text-xs font-semibold text-white opacity-20 backdrop-blur transition hover:opacity-100"
              >
                Exit recording mode
              </button>
            ) : null}
          </div>
        </div>

        {!isRecordingMode ? (
          <>
            <div className="rounded-[2rem] border border-white/10 bg-white/[0.06] p-4 text-slate-200">
              <div className="flex flex-wrap items-center gap-2">
                {scenes.map((item, index) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      setSceneIndex(index);
                      setIsPlaying(false);
                    }}
                    className={`rounded-full border px-3 py-2 text-xs font-semibold transition ${
                      index === sceneIndex
                        ? "border-violet-300 bg-violet-500 text-white"
                        : "border-white/10 bg-white/[0.03] text-slate-300 hover:bg-white/[0.07]"
                    }`}
                  >
                    {item.title.replace(".", "")}
                  </button>
                ))}
              </div>
            </div>

            <section className="rounded-[2rem] border border-white/10 bg-white/[0.06] text-slate-200">
              <button
                type="button"
                onClick={() => setIsScriptOpen((value) => !value)}
                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
              >
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.2em] text-violet-300">
                    Voiceover script
                  </p>
                  <p className="mt-1 text-sm text-slate-400">
                    Use this while recording, then enable Recording Mode for a clean capture.
                  </p>
                </div>
                <span className="rounded-full border border-white/10 px-3 py-1 text-xs font-semibold text-slate-300">
                  {isScriptOpen ? "Hide" : "Show"}
                </span>
              </button>

              {isScriptOpen ? (
                <div className="border-t border-white/10 p-5">
                  <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                    {scenes.map((item, index) => (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => {
                          setSceneIndex(index);
                          setIsPlaying(false);
                        }}
                        className={`rounded-2xl border p-4 text-left transition ${
                          index === sceneIndex
                            ? "border-violet-400 bg-violet-500/15 text-white"
                            : "border-white/10 bg-white/[0.03] hover:bg-white/[0.07]"
                        }`}
                      >
                        <span className="block text-xs font-semibold uppercase tracking-[0.16em] text-violet-300">
                          {item.eyebrow}
                        </span>
                        <span className="mt-2 block text-sm leading-6">“{item.script}”</span>
                      </button>
                    ))}
                  </div>

                  <label className="mt-5 block text-xs font-semibold uppercase tracking-[0.18em] text-slate-400">
                    Full script
                  </label>
                  <textarea
                    readOnly
                    value={script}
                    className="mt-2 h-44 w-full rounded-2xl border border-white/10 bg-slate-950/60 p-4 text-xs leading-5 text-slate-300 outline-none"
                  />
                </div>
              ) : null}
            </section>
          </>
        ) : null}
      </div>
    </div>
  );
}

function MarketingLogo({ size = 28 }: { size?: number }) {
  return (
    <img
      src="/AFLogo.png"
      alt="AuditFlow"
      className="h-auto shrink-0"
      style={{ width: size }}
    />
  );
}

function Cursor({ left, top }: { left: string; top: string }) {
  return (
    <div
      className="pointer-events-none absolute z-30 transition-all duration-[900ms] ease-in-out"
      style={{ left, top, transform: "translate(-8px, -6px)" }}
    >
      <MousePointer2 className="h-8 w-8 fill-violet-600 text-violet-600 drop-shadow-lg" />
      <span className="absolute -right-2 -top-2 h-5 w-5 animate-ping rounded-full bg-violet-400/50" />
    </div>
  );
}

function MarketingScreen({ scene }: { scene: SceneId }) {
  if (scene === "landing") return <LandingShot />;
  if (scene === "dashboard") return <DashboardShot />;
  if (scene === "createProject") return <CreateProjectShot />;
  if (scene === "findings") return <FindingsShot />;
  if (scene === "journeys") return <JourneysShot />;
  if (scene === "recommendations") return <RecommendationsShot />;
  if (scene === "reports") return <ReportsShot />;
  if (scene === "portal") return <PortalShot />;
  return <EndingShot />;
}

function AppChrome({ children, active = "Dashboard" }: { children: ReactNode; active?: string }) {
  const nav = ["Dashboard", "Projects", "Clients", "Reports", "Recommendations", "Frameworks"];
  return (
    <div className="grid h-full grid-cols-[220px_minmax(0,1fr)] bg-slate-100 text-slate-900">
      <aside className="border-r border-slate-200 bg-white p-5">
        <MarketingLogo size={26} />
        <div className="mt-8 space-y-1">
          {nav.map((item) => (
            <div
              key={item}
              className={`rounded-xl px-3 py-2.5 text-sm font-semibold ${
                item === active ? "bg-violet-50 text-violet-700" : "text-slate-500"
              }`}
            >
              {item}
            </div>
          ))}
        </div>
      </aside>
      <main className="overflow-hidden p-7">{children}</main>
    </div>
  );
}

function LandingShot() {
  return (
    <div className="flex h-full items-center justify-center bg-white px-10 text-center text-slate-950">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,#ede9fe,transparent_42%)]" />
      <div className="relative max-w-4xl">
        <MarketingLogo />
        <p className="mx-auto mt-10 inline-flex rounded-full border border-violet-100 bg-violet-50 px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-violet-600">
          UX audit platform
        </p>
        <h2 className="mt-6 text-6xl font-semibold leading-[1.02] tracking-[-0.06em]">
          Organize UX audits from insight to action.
        </h2>
        <p className="mx-auto mt-6 max-w-2xl text-lg leading-8 text-slate-600">
          Capture findings, connect evidence, map journeys, and create stakeholder-ready reports.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <span className="rounded-xl bg-violet-600 px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-violet-200">
            Start free
          </span>
          <span className="rounded-xl border border-slate-200 bg-white px-6 py-3 text-sm font-semibold text-slate-700">
            See the workflow
          </span>
        </div>
      </div>
    </div>
  );
}

function DashboardShot() {
  return (
    <AppChrome active="Dashboard">
      <Header title="Welcome, Jamie" subtitle="4 projects, 27 findings, and 8 client-ready reports." action="+ New Project" />
      <div className="mt-7 grid grid-cols-4 gap-4">
        <Stat value="4" label="Projects" />
        <Stat value="27" label="Findings" />
        <Stat value="16" label="Recommendations" />
        <Stat value="8" label="Reports" />
      </div>
      <div className="mt-8 grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
        <Card title="Recent projects">
          <MiniProject title="Nova Commerce Checkout" meta="In Progress • 12 findings" />
          <MiniProject title="BrightPath Learning Audit" meta="In Review • 8 findings" />
          <MiniProject title="Horizon Health Portal" meta="Complete • 7 findings" />
        </Card>
        <Card title="Audit health">
          <Progress label="Open findings" value="65%" />
          <Progress label="In review" value="35%" />
          <Progress label="Completed" value="72%" />
        </Card>
      </div>
    </AppChrome>
  );
}

function CreateProjectShot() {
  return (
    <AppChrome active="Projects">
      <Header title="New Project" subtitle="Set up a focused workspace for a new audit." />
      <div className="mx-auto mt-6 max-w-2xl rounded-3xl border border-slate-200 bg-white p-7 shadow-sm">
        <Field label="Project name" value="Nova Commerce Checkout" active />
        <Field label="Client" value="Nova Commerce" />
        <Field label="Website URL" value="https://novacommerce.example" />
        <Field label="Audit type" value="Ecommerce" select />
        <div className="mt-7 grid grid-cols-2 gap-3">
          <span className="rounded-2xl border border-slate-200 px-5 py-3 text-center text-sm font-semibold text-slate-700">Cancel</span>
          <span className="rounded-2xl bg-violet-600 px-5 py-3 text-center text-sm font-semibold text-white">Create Project</span>
        </div>
      </div>
    </AppChrome>
  );
}

function FindingsShot() {
  return (
    <AppChrome active="Projects">
      <Header title="Nova Commerce Checkout" subtitle="Findings, evidence, journeys, and reports in one project." action="+ Add Finding" />
      <div className="mt-6 grid grid-cols-[1fr_180px] gap-4">
        <SearchPill text="Search findings..." />
        <SelectPill text="Severity" />
      </div>
      <div className="mt-5 overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
        <TableHeader cols="grid-cols-[1.35fr_0.45fr_0.55fr_0.9fr]" items={["Finding", "Severity", "Status", "Recommendation"]} />
        <FindingRow title="Primary CTA lacks contrast" severity="P1" status="Open" rec="Increase visual contrast" />
        <FindingRow title="Checkout validation is unclear" severity="P2" status="In Review" rec="Improve error messaging" />
        <FindingRow title="Confirmation feedback is easy to miss" severity="P2" status="Open" rec="Add persistent success state" />
      </div>
    </AppChrome>
  );
}

function JourneysShot() {
  return (
    <AppChrome active="Projects">
      <Header title="User Journeys" subtitle="Map friction to the exact point in the experience." action="+ Add Journey" />
      <div className="mt-7 grid gap-5 lg:grid-cols-3">
        {[
          ["Product Discovery", "Search filters are difficult to discover", "3 findings"],
          ["Checkout", "Checkout validation is unclear", "5 findings"],
          ["Confirmation", "Confirmation feedback is easy to miss", "2 findings"],
        ].map(([title, finding, count]) => (
          <div key={title} className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between gap-3">
              <h3 className="text-lg font-semibold text-slate-950">{title}</h3>
              <span className="rounded-full bg-violet-50 px-3 py-1 text-xs font-semibold text-violet-700">{count}</span>
            </div>
            <div className="mt-5 rounded-2xl border border-slate-200 bg-slate-50 p-4 text-sm font-medium text-slate-700">
              {finding}
            </div>
          </div>
        ))}
      </div>
    </AppChrome>
  );
}

function RecommendationsShot() {
  return (
    <AppChrome active="Recommendations">
      <Header title="Recommendation Library" subtitle="Reuse your best UX guidance across audits." action="+ New Recommendation" />
      <div className="mt-6 max-w-md"><SearchPill text="Search recommendations..." /></div>
      <div className="mt-6 overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
        <TableHeader cols="grid-cols-[1.5fr_0.6fr_0.55fr_0.5fr]" items={["Recommendation", "Category", "Impact", "Actions"]} />
        <div className="grid grid-cols-[1.5fr_0.6fr_0.55fr_0.5fr] items-center gap-4 border-t border-slate-100 px-5 py-5 text-sm">
          <div>
            <p className="font-semibold text-slate-950">Increase visual contrast</p>
            <p className="mt-1 truncate text-slate-500">Make primary actions easier to identify.</p>
          </div>
          <span>Visual Design</span>
          <span>High</span>
          <span className="text-right font-semibold text-violet-700">Apply</span>
        </div>
      </div>
    </AppChrome>
  );
}

function ReportsShot() {
  return (
    <AppChrome active="Projects">
      <Header title="Nova Commerce Checkout" subtitle="Reports are generated from the project workspace." />
      <div className="mt-5 flex gap-2">
        {"Overview Findings Evidence Journeys Reports".split(" ").map((tab) => (
          <span key={tab} className={`rounded-xl px-4 py-2 text-sm font-semibold ${tab === "Reports" ? "bg-violet-600 text-white" : "bg-white text-slate-600"}`}>{tab}</span>
        ))}
      </div>
      <div className="mt-6 grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
        <Card title="Report builder">
          <ReportOption title="Professional Report" active />
          <ReportOption title="Executive Summary" />
          <ReportOption title="Findings Only" />
          <span className="mt-5 block rounded-2xl bg-violet-600 px-5 py-3 text-center text-sm font-semibold text-white">Preview PDF</span>
        </Card>
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-6">
            <div className="flex items-center gap-3"><FileText className="text-violet-600" /><h3 className="text-xl font-semibold">Nova Commerce UX Audit</h3></div>
            <div className="mt-6 space-y-3 text-sm text-slate-600">
              <p>Executive summary</p><p>Priority findings</p><p>Recommendations</p><p>Implementation roadmap</p>
            </div>
          </div>
          <div className="mt-5 flex justify-end"><span className="inline-flex items-center gap-2 rounded-2xl bg-slate-950 px-5 py-3 text-sm font-semibold text-white"><Download size={16} /> Export PDF</span></div>
        </div>
      </div>
    </AppChrome>
  );
}

function PortalShot() {
  return (
    <div className="h-full bg-slate-50 p-8 text-slate-900">
      <div className="mx-auto max-w-5xl">
        <div className="flex items-center justify-between rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
          <MarketingLogo />
          <span className="inline-flex items-center gap-2 rounded-full bg-violet-50 px-4 py-2 text-sm font-semibold text-violet-700"><Bell size={16} /> 2 updates</span>
        </div>
        <div className="mt-6 grid gap-5 lg:grid-cols-[1.1fr_0.9fr]">
          <Card title="Nova Commerce Checkout">
            <MiniProject title="Client workspace" meta="Reports, findings, and replies in one place" />
            <MiniProject title="Professional report" meta="Ready for review" />
          </Card>
          <Card title="Notifications">
            <Notification text="Jamie replied to Confirmation feedback is easy to miss" />
            <Notification text="Jamie replied to Checkout validation is unclear" />
          </Card>
        </div>
        <div className="mt-5 rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-start gap-3">
            <MessageSquare className="mt-1 text-violet-600" />
            <div>
              <p className="font-semibold text-slate-950">Client comment</p>
              <p className="mt-1 text-sm text-slate-600">Can we clarify the recommendation for checkout errors?</p>
              <p className="mt-4 rounded-2xl bg-violet-50 p-4 text-sm text-violet-900">Jamie replied: Yes — I added implementation guidance and priority notes.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function EndingShot() {
  return (
    <div className="flex h-full items-center justify-center bg-slate-950 text-center text-white">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,#4c1d95,transparent_46%)] opacity-70" />
      <div className="relative">
        <div className="inline-flex rounded-3xl bg-white p-5"><MarketingLogo size={34} /></div>
        <h2 className="mt-8 text-6xl font-semibold tracking-[-0.06em]">From insight to action.</h2>
        <p className="mt-5 text-lg text-violet-100">Professional UX audits, simplified.</p>
      </div>
    </div>
  );
}

function Header({ title, subtitle, action }: { title: string; subtitle: string; action?: string }) {
  return <div className="flex items-start justify-between gap-6"><div><h2 className="text-[30px] font-semibold tracking-[-0.04em] text-slate-950">{title}</h2><p className="mt-2 text-base text-slate-500">{subtitle}</p></div>{action ? <span className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-200">{action}</span> : null}</div>;
}
function Stat({ value, label }: { value: string; label: string }) { return <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"><p className="text-3xl font-semibold text-slate-950">{value}</p><p className="mt-2 text-sm font-medium text-slate-500">{label}</p></div>; }
function Card({ title, children }: { title: string; children: ReactNode }) { return <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm"><h3 className="text-xl font-semibold text-slate-950">{title}</h3><div className="mt-5 space-y-3">{children}</div></div>; }
function MiniProject({ title, meta }: { title: string; meta: string }) { return <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4"><p className="font-semibold text-slate-950">{title}</p><p className="mt-1 text-sm text-slate-500">{meta}</p></div>; }
function Progress({ label, value }: { label: string; value: string }) { return <div><div className="flex justify-between text-sm"><span className="font-medium text-slate-700">{label}</span><span className="text-slate-500">{value}</span></div><div className="mt-2 h-2 rounded-full bg-slate-100"><div className="h-2 rounded-full bg-violet-500" style={{ width: value }} /></div></div>; }
function Field({ label, value, active, select }: { label: string; value: string; active?: boolean; select?: boolean }) { return <div className="mt-4"><p className="mb-2 text-sm font-semibold text-slate-700">{label}</p><div className={`flex items-center justify-between rounded-2xl border px-4 py-3 text-sm ${active ? "border-violet-200 bg-violet-50 text-violet-900" : "border-slate-200 bg-white text-slate-700"}`}><span>{value}</span>{select ? <span className="text-slate-400">⌄</span> : null}</div></div>; }
function SearchPill({ text }: { text: string }) { return <div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-400 shadow-sm"><Search size={16} /><span>{text}</span></div>; }
function SelectPill({ text }: { text: string }) { return <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 shadow-sm"><span>{text}</span><span className="text-slate-400">⌄</span></div>; }
function TableHeader({ cols, items }: { cols: string; items: string[] }) { return <div className={`grid ${cols} gap-4 bg-slate-50 px-5 py-4 text-xs font-semibold uppercase tracking-wide text-slate-500`}>{items.map((item) => <span key={item}>{item}</span>)}</div>; }
function FindingRow({ title, severity, status, rec }: { title: string; severity: string; status: string; rec: string }) { return <div className="grid grid-cols-[1.35fr_0.45fr_0.55fr_0.9fr] items-center gap-4 border-t border-slate-100 px-5 py-4 text-sm"><span className="font-semibold text-slate-950">{title}</span><span className="font-semibold text-violet-700">{severity}</span><span>{status}</span><span className="truncate text-slate-500">{rec}</span></div>; }
function ReportOption({ title, active }: { title: string; active?: boolean }) { return <div className={`rounded-2xl border p-4 ${active ? "border-violet-200 bg-violet-50" : "border-slate-200 bg-white"}`}><p className="font-semibold text-slate-950">{title}</p><p className="mt-1 text-sm text-slate-500">Client-ready export option</p></div>; }
function Notification({ text }: { text: string }) { return <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4"><p className="text-xs font-semibold uppercase tracking-wide text-violet-600">Auditor reply</p><p className="mt-1 text-sm font-medium text-slate-700">{text}</p></div>; }
