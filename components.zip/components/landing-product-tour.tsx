"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ElementType, ReactNode } from "react";
import {
  BarChart3,
  Building2,
  CreditCard,
  FileText,
  FolderKanban,
  LayoutDashboard,
  Lightbulb,
  LogOut,
  Settings,
  Shapes,
} from "lucide-react";
import { BrandLogo } from "@/components/brand-logo";

type WorkflowStepId =
  | "dashboard"
  | "analytics"
  | "clients"
  | "frameworks"
  | "manageProject"
  | "exportReport";

type ScreenId =
  | "dashboard"
  | "analytics"
  | "clients"
  | "projects"
  | "projectsForFramework"
  | "createProject"
  | "frameworks"
  | "projectOverview"
  | "createdProjectOverview"
  | "frameworkApplied"
  | "newFinding"
  | "evidence"
  | "journeys"
  | "recommendations"
  | "reports"
  | "reportExported";

type SidebarItemId = "dashboard" | "analytics" | "projects" | "clients" | "reports" | "recommendations" | "frameworks";

type TourAction = {
  id: ScreenId;
  workflow: WorkflowStepId;
  sidebar: SidebarItemId;
  label: string;
  description: string;
  targetKey: string;
};

const workflowSteps: { id: WorkflowStepId; label: string }[] = [
  { id: "dashboard", label: "Dashboard" },
  { id: "analytics", label: "Analytics" },
  { id: "clients", label: "Clients" },
  { id: "frameworks", label: "Frameworks" },
  { id: "manageProject", label: "Project Work" },
  { id: "exportReport", label: "Reports" },
];

const tourActions: TourAction[] = [
  {
    id: "dashboard",
    workflow: "dashboard",
    sidebar: "dashboard",
    label: "Track audit work",
    description:
      "Start from a portfolio view of active audits, recommendations, open findings, and recent work.",
    targetKey: "sidebar-dashboard",
  },
  {
    id: "analytics",
    workflow: "analytics",
    sidebar: "analytics",
    label: "Review audit health",
    description:
      "Use analytics to see where findings, project status, and audit activity are concentrated.",
    targetKey: "sidebar-analytics",
  },
  {
    id: "clients",
    workflow: "clients",
    sidebar: "clients",
    label: "Manage clients",
    description:
      "Studio workspaces keep each client’s projects, reports, brand assets, and activity together.",
    targetKey: "sidebar-clients",
  },
  {
    id: "projects",
    workflow: "clients",
    sidebar: "projects",
    label: "View projects",
    description:
      "Browse existing projects, continue active audits, or start something new for a client.",
    targetKey: "sidebar-projects",
  },
  {
    id: "projectOverview",
    workflow: "clients",
    sidebar: "projects",
    label: "Open an existing audit",
    description:
      "Open a project to review findings, journeys, evidence, recommendations, and report progress.",
    targetKey: "project-row-checkout",
  },
  {
    id: "projectsForFramework",
    workflow: "frameworks",
    sidebar: "projects",
    label: "Start a new audit",
    description:
      "Return to Projects when it is time to create another audit workspace.",
    targetKey: "sidebar-projects",
  },
  {
    id: "createProject",
    workflow: "frameworks",
    sidebar: "projects",
    label: "Create a project",
    description:
      "Start blank or choose a reusable Studio framework when the audit should follow a standard process.",
    targetKey: "new-project-button",
  },
  {
    id: "frameworks",
    workflow: "frameworks",
    sidebar: "frameworks",
    label: "Choose a framework",
    description:
      "Projects can start blank, or use a framework for categories, journeys, recommendations, and report defaults.",
    targetKey: "use-framework-button",
  },
  {
    id: "frameworkApplied",
    workflow: "manageProject",
    sidebar: "projects",
    label: "Apply the framework",
    description:
      "Frameworks can bring in categories, journey stages, recommendations, and report defaults.",
    targetKey: "framework-card-saas",
  },
  {
    id: "createdProjectOverview",
    workflow: "manageProject",
    sidebar: "projects",
    label: "Manage the project",
    description:
      "The project workspace keeps findings, evidence, journeys, recommendations, and reports connected.",
    targetKey: "new-finding-button",
  },
  {
    id: "newFinding",
    workflow: "manageProject",
    sidebar: "projects",
    label: "Add findings",
    description:
      "Capture severity, impact, effort, journey context, and a recommended next step while the issue is fresh.",
    targetKey: "add-evidence-button",
  },
  {
    id: "evidence",
    workflow: "manageProject",
    sidebar: "projects",
    label: "Attach evidence",
    description:
      "Add screenshots and captions so stakeholders can understand exactly what happened.",
    targetKey: "save-finding-button",
  },
  {
    id: "journeys",
    workflow: "manageProject",
    sidebar: "projects",
    label: "Map user journeys",
    description:
      "Connect findings to the exact steps where users experience friction.",
    targetKey: "tab-journeys",
  },
  {
    id: "recommendations",
    workflow: "manageProject",
    sidebar: "recommendations",
    label: "Reuse recommendations",
    description:
      "Studio teams can maintain reusable guidance and insert it into findings for consistent deliverables.",
    targetKey: "sidebar-recommendations",
  },
  {
    id: "reports",
    workflow: "exportReport",
    sidebar: "reports",
    label: "Build reports",
    description:
      "Choose the right report template, preview sections, and apply client branding before export.",
    targetKey: "tab-reports",
  },
  {
    id: "reportExported",
    workflow: "exportReport",
    sidebar: "reports",
    label: "Export and save history",
    description:
      "Export a polished PDF and keep the report available in project and client history.",
    targetKey: "export-pdf-button",
  },
];

export function LandingProductTour() {
  const [activeActionId, setActiveActionId] = useState<ScreenId>("dashboard");
  const [pointerActionId, setPointerActionId] = useState<ScreenId>("dashboard");
  const [isClicking, setIsClicking] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);
  const [pointerPosition, setPointerPosition] = useState({
    left: "50%",
    top: "50%",
    visible: false,
  });
  const tourFrameRef = useRef<HTMLDivElement | null>(null);
  const timers = useRef<number[]>([]);

  const activeIndex = tourActions.findIndex(
    (action) => action.id === activeActionId,
  );
  const activeAction = tourActions[activeIndex] ?? tourActions[0];
  const pointerTarget = useMemo(
    () =>
      tourActions.find((action) => action.id === pointerActionId) ??
      activeAction,
    [activeAction, pointerActionId],
  );

  const updatePointerPosition = useCallback(() => {
    const frame = tourFrameRef.current;
    if (!frame) return;

    const target = frame.querySelector<HTMLElement>(
      `[data-tour-target="${pointerTarget.targetKey}"]`,
    );

    if (!target) {
      setPointerPosition((position) => ({ ...position, visible: false }));
      return;
    }

    const frameRect = frame.getBoundingClientRect();
    const targetRect = target.getBoundingClientRect();

    setPointerPosition({
      left: `${targetRect.left - frameRect.left + targetRect.width / 2}px`,
      top: `${targetRect.top - frameRect.top + targetRect.height / 2}px`,
      visible: true,
    });
  }, [pointerTarget.targetKey]);

  const activeWorkflowIndex = workflowSteps.findIndex(
    (step) => step.id === activeAction.workflow,
  );

  function clearTimers() {
    timers.current.forEach((timer) => window.clearTimeout(timer));
    timers.current = [];
  }

  function moveToAction(nextActionId: ScreenId) {
    clearTimers();
    setPointerActionId(nextActionId);
    setIsClicking(false);

    timers.current.push(
      window.setTimeout(() => {
        setIsClicking(true);
      }, 760),
    );

    timers.current.push(
      window.setTimeout(() => {
        setActiveActionId(nextActionId);
      }, 1040),
    );

    timers.current.push(
      window.setTimeout(() => {
        setIsClicking(false);
      }, 1220),
    );
  }

  function moveToWorkflow(workflow: WorkflowStepId) {
    const nextAction = tourActions.find(
      (action) => action.workflow === workflow,
    );
    if (!nextAction) return;
    setIsPlaying(false);
    moveToAction(nextAction.id);
  }

  useEffect(() => {
    updatePointerPosition();
    const raf = window.requestAnimationFrame(updatePointerPosition);
    window.addEventListener("resize", updatePointerPosition);
    return () => {
      window.cancelAnimationFrame(raf);
      window.removeEventListener("resize", updatePointerPosition);
    };
  }, [activeActionId, pointerActionId, updatePointerPosition]);

  useEffect(() => {
    if (!isPlaying) return;

    const timer = window.setTimeout(
      () => {
        const next = tourActions[(activeIndex + 1) % tourActions.length].id;
        moveToAction(next);
      },
      activeAction.workflow === "manageProject" ||
        activeAction.workflow === "frameworks"
        ? 2500
        : 3200,
    );

    return () => window.clearTimeout(timer);
  }, [activeAction.workflow, activeIndex, isPlaying]);

  useEffect(() => clearTimers, []);

  return (
    <section id="tour" className="mx-auto max-w-7xl px-6 py-12 sm:px-8">
      <div className="mx-auto mb-8 max-w-3xl text-center">
        <p className="text-sm font-semibold uppercase tracking-[0.18em] text-violet-600">
          Product tour
        </p>
        <h2 className="mt-4 text-3xl font-semibold tracking-[-0.04em] text-slate-950 sm:text-5xl">
          See the AuditFlow workflow in action.
        </h2>
        <p className="mt-4 text-base leading-7 text-slate-600">
          Follow the current AuditFlow workflow from portfolio analytics to client workspaces, reusable frameworks, findings, evidence, journeys, recommendations, and report history.
        </p>
      </div>

      <div className="overflow-hidden rounded-[2rem] border border-slate-200 bg-slate-100 shadow-xl shadow-slate-200/70">
        <div className="flex h-11 items-center gap-2 border-b border-slate-200 bg-white px-5">
          <span className="h-3 w-3 rounded-full bg-red-400" />
          <span className="h-3 w-3 rounded-full bg-yellow-400" />
          <span className="h-3 w-3 rounded-full bg-green-500" />
          <span className="ml-5 rounded-full bg-slate-100 px-5 py-1.5 text-xs font-semibold text-slate-500">
            auditflow.app/workspace
          </span>
          <button
            type="button"
            onClick={() => setIsPlaying((value) => !value)}
            className="ml-auto rounded-full border border-slate-200 px-3 py-1.5 text-xs font-semibold text-slate-700 hover:bg-slate-50"
          >
            {isPlaying ? "Pause" : "Play"}
          </button>
        </div>

        <div
          ref={tourFrameRef}
          className="relative grid h-[660px] grid-cols-[240px_minmax(0,1fr)] overflow-hidden bg-slate-100"
        >
          <AppSidebar active={activeAction.sidebar} />
          <main className="overflow-hidden bg-slate-100 p-7">
            <ProductScreen screen={activeActionId} />
          </main>
          <MovingClickDot
            left={pointerPosition.left}
            top={pointerPosition.top}
            visible={pointerPosition.visible}
            isClicking={isClicking}
          />
        </div>
      </div>

      <div className="mx-auto mt-5 max-w-3xl text-center">
        <p className="text-sm font-semibold text-violet-700">
          {activeAction.label}
        </p>
        <p className="mt-1 text-sm leading-6 text-slate-600">
          {activeAction.description}
        </p>
      </div>

      <div className="mx-auto mt-6 max-w-6xl overflow-x-auto pb-2">
        <div className="flex min-w-max items-center justify-center gap-2 px-1">
          {workflowSteps.map((step, index) => {
            const isActive = step.id === activeAction.workflow;
            const isComplete = index < activeWorkflowIndex;

            return (
              <button
                key={step.id}
                type="button"
                onClick={() => moveToWorkflow(step.id)}
                className={`flex shrink-0 items-center gap-2 rounded-full border px-3.5 py-2 text-xs font-semibold transition ${
                  isActive
                    ? "border-violet-200 bg-violet-50 text-violet-700"
                    : isComplete
                      ? "border-slate-200 bg-white text-slate-700"
                      : "border-slate-200 bg-white/80 text-slate-500 hover:bg-white"
                }`}
              >
                <span
                  className={`flex h-5 w-5 items-center justify-center rounded-full text-[10px] ${
                    isActive
                      ? "bg-violet-600 text-white"
                      : isComplete
                        ? "bg-slate-900 text-white"
                        : "bg-slate-100 text-slate-500"
                  }`}
                >
                  {isComplete ? "✓" : index + 1}
                </span>
                <span className="whitespace-nowrap">{step.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function MovingClickDot({
  left,
  top,
  visible,
  isClicking,
}: {
  left: string;
  top: string;
  visible: boolean;
  isClicking: boolean;
}) {
  return (
    <div
      className={`pointer-events-none absolute z-30 transition-all duration-[850ms] ease-in-out ${visible ? "opacity-100" : "opacity-0"}`}
      style={{ left, top, transform: "translate(-50%, -50%)" }}
      aria-hidden="true"
    >
      <div
        className={`h-3.5 w-3.5 rounded-full bg-violet-300 shadow-sm transition-transform duration-150 ${
          isClicking ? "scale-75" : "scale-100"
        }`}
      />
    </div>
  );
}

function AppSidebar({ active }: { active: SidebarItemId }) {
  const workspaceItems = [
    { id: "dashboard" as const, label: "Dashboard", icon: LayoutDashboard },
    { id: "analytics" as const, label: "Analytics", icon: BarChart3 },
  ];

  const auditItems = [
    { id: "projects" as const, label: "Projects", icon: FolderKanban },
    { id: "clients" as const, label: "Clients", icon: Building2 },
    { id: "reports" as const, label: "Reports", icon: FileText },
    { id: "recommendations" as const, label: "Recommendations", icon: Lightbulb },
    { id: "frameworks" as const, label: "Frameworks", icon: Shapes },
  ];

  return (
    <aside className="flex min-h-0 flex-col border-r border-slate-200 bg-white">
      <div className="border-b border-slate-200 px-5 py-4">
        <BrandLogo size={26} />
      </div>

      <nav className="flex-1 px-4 py-5">
        <p className="mb-3 px-3 text-[11px] font-semibold uppercase tracking-wide text-slate-400">
          Workspace
        </p>
        <div className="space-y-1">
          {workspaceItems.map((item) => (
            <SidebarNavItem
              key={item.id}
              item={item}
              active={active === item.id}
            />
          ))}
        </div>

        <p className="mb-3 mt-7 px-3 text-[11px] font-semibold uppercase tracking-wide text-slate-400">
          Audits
        </p>
        <div className="space-y-1">
          {auditItems.map((item) => (
            <SidebarNavItem
              key={item.id}
              item={item}
              active={active === item.id}
            />
          ))}
        </div>
      </nav>

      <div className="border-t border-slate-200 p-4">
        <SidebarUtility icon={Settings} label="Settings" />
        <SidebarUtility icon={CreditCard} label="Billing" />

        <div className="mt-4 rounded-2xl bg-slate-50 p-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-violet-100 text-sm font-semibold text-violet-700">
              JR
            </div>
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-slate-900">
                Jamie Robinson
              </p>
              <p className="truncate text-xs text-slate-500">
                jamie@auditflow.app
              </p>
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2 text-xs font-medium text-slate-500">
            <LogOut size={14} />
            Sign out
          </div>
        </div>
      </div>
    </aside>
  );
}

function SidebarNavItem({
  item,
  active,
}: {
  item: { id?: string; label: string; icon: ElementType };
  active: boolean;
}) {
  const Icon = item.icon;

  return (
    <div
      data-tour-target={item.id ? `sidebar-${item.id}` : undefined}
      className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium ${
        active ? "bg-violet-50 text-violet-700" : "text-slate-600"
      }`}
    >
      <Icon size={18} strokeWidth={2} />
      {item.label}
    </div>
  );
}

function SidebarUtility({
  icon: Icon,
  label,
}: {
  icon: ElementType;
  label: string;
}) {
  return (
    <div className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-slate-600">
      <Icon size={18} strokeWidth={2} />
      {label}
    </div>
  );
}

function ProductScreen({ screen }: { screen: ScreenId }) {
  if (screen === "analytics") return <AnalyticsScreen />;
  if (screen === "clients") return <ClientsScreen />;
  if (screen === "projects" || screen === "projectsForFramework") return <ProjectsScreen />;
  if (screen === "createProject") return <CreateProjectScreen />;
  if (screen === "frameworks") return <FrameworksScreen />;
  if (screen === "projectOverview")
    return (
      <ProjectOverviewScreen
        projectName="Checkout Optimization Audit"
        projectUrl="shopdemo.io/checkout"
        existing
      />
    );
  if (screen === "frameworkApplied")
    return (
      <ProjectOverviewScreen
        projectName="SaaS Onboarding Audit"
        projectUrl="acme.io/onboarding"
      />
    );
  if (screen === "createdProjectOverview")
    return (
      <ProjectOverviewScreen
        projectName="Mobile App Onboarding Audit"
        projectUrl="mobileapp.example"
      />
    );
  if (screen === "newFinding") return <NewFindingScreen />;
  if (screen === "evidence") return <EvidenceScreen />;
  if (screen === "journeys") return <JourneyMapsScreen />;
  if (screen === "recommendations") return <RecommendationLibraryScreen />;
  if (screen === "reports") return <ReportsScreen />;
  if (screen === "reportExported") return <ReportsScreen exported />;
  return <DashboardScreen />;
}

function DashboardScreen() {
  return (
    <div className="h-full">
      <div className="flex items-start justify-between gap-6">
        <div>
          <h3 className="text-[28px] font-semibold tracking-[-0.04em] text-slate-950">
            Welcome, Jamie Robinson
          </h3>
          <p className="mt-3 text-base text-slate-500">
            You have 4 projects, 16 findings, 11 recommendations, and 13 open findings.
          </p>
        </div>
        <span
          data-tour-target="new-project-button"
          className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-200"
        >
          + New Project
        </span>
      </div>

      <div className="mt-8 grid grid-cols-4 gap-4">
        <DashboardStat
          value="4"
          label="Projects"
          description="Based on your audit data"
        />
        <DashboardStat
          value="16"
          label="Findings"
          description="Across active audits"
        />
        <DashboardStat
          value="11"
          label="Recommendations"
          description="Ready for review"
        />
        <DashboardStat
          value="2"
          label="Completed Audits"
          description="Based on your audit data"
        />
      </div>

      <div className="mt-8">
        <h4 className="text-xl font-semibold text-slate-950">
          Recent Projects
        </h4>
        <div className="mt-5 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
          <div className="grid grid-cols-[1.4fr_0.9fr_0.8fr_0.9fr] bg-slate-50 px-6 py-4 text-xs font-semibold uppercase tracking-wide text-slate-500">
            <span>Project</span>
            <span>Type</span>
            <span>Findings</span>
            <span>Status</span>
          </div>
          <ProjectTableRow
            name="Checkout Optimization Audit"
            url="shopdemo.io/checkout"
            type="Ecommerce"
            findings="8"
            status="In Progress"
          />
          <ProjectTableRow
            name="Mobile App Onboarding Audit"
            url="mobileapp.example"
            type="Mobile App"
            findings="5"
            status="In Progress"
          />
          <ProjectTableRow
            name="Pricing Page Conversion Review"
            url="acme.io/pricing"
            type="SaaS"
            findings="3"
            status="Completed"
          />
        </div>
      </div>
    </div>
  );
}

function AnalyticsScreen() {
  return (
    <div className="h-full">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-[28px] font-semibold tracking-[-0.04em] text-slate-950">
            Analytics
          </h3>
          <p className="mt-2 text-base text-slate-500">
            Portfolio and finding-level insights across your audit work.
          </p>
        </div>
        <span className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-900 shadow-sm">
          Dashboard
        </span>
      </div>

      <div className="mt-8">
        <h4 className="text-xl font-semibold text-slate-950">
          Portfolio Overview
        </h4>
        <p className="mt-2 text-base text-slate-500">
          Project-level health across your audit portfolio.
        </p>
      </div>

      <div className="mt-5 grid grid-cols-4 gap-4">
        <DashboardStat
          value="4"
          label="Total projects"
          description="All audit projects"
        />
        <DashboardStat
          value="16"
          label="Total findings"
          description="Across all projects"
        />
        <DashboardStat
          value="4.0"
          label="Avg. findings / project"
          description="Audit size indicator"
        />
        <DashboardStat
          value="2"
          label="Completed projects"
          description="Project status = completed"
        />
      </div>

      <div className="mt-8 grid gap-5 lg:grid-cols-2">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h4 className="text-xl font-semibold text-slate-950">
            Projects by status
          </h4>
          <p className="mt-2 text-sm text-slate-500">
            Current status of your audit projects.
          </p>
          <div className="mt-8 flex items-center gap-10">
            <div className="flex h-36 w-36 items-center justify-center rounded-full bg-[conic-gradient(#22c55e_0_50%,#8b5cf6_50%_100%)]">
              <div className="flex h-20 w-20 flex-col items-center justify-center rounded-full bg-white">
                <span className="text-2xl font-semibold text-slate-950">4</span>
                <span className="text-xs text-slate-500">Projects</span>
              </div>
            </div>
            <div className="flex-1 space-y-5">
              <ProgressRow label="In Progress" value="2 / 50%" width="50%" />
              <ProgressRow
                label="Completed"
                value="2 / 50%"
                width="50%"
                color="bg-green-500"
              />
            </div>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h4 className="text-xl font-semibold text-slate-950">
            Findings by project
          </h4>
          <p className="mt-2 text-sm text-slate-500">
            Top projects by finding volume.
          </p>
          <div className="mt-8 space-y-5">
            <BarRow
              title="Checkout Optimization Audit"
              subtitle="8 open findings"
              value="8 findings"
              width="100%"
            />
            <BarRow
              title="Mobile App Onboarding Audit"
              subtitle="5 open findings"
              value="5 findings"
              width="62%"
            />
            <BarRow
              title="Pricing Page Conversion Review"
              subtitle="3 resolved findings"
              value="3 findings"
              width="38%"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function CreateProjectScreen() {
  return (
    <div className="h-full">
      <div className="flex items-start justify-between gap-6">
        <div>
          <h3 className="text-[28px] font-semibold tracking-[-0.04em] text-slate-950">
            Create Project
          </h3>
          <p className="mt-2 text-base text-slate-500">
            Start from scratch or use a framework when you want a guided audit
            structure.
          </p>
        </div>
        <span className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-200">
          Create Project
        </span>
      </div>

      <div className="mx-auto mt-8 max-w-3xl rounded-[1.75rem] border border-slate-200 bg-white p-6 shadow-sm">
        <div className="flex items-start justify-between gap-5 border-b border-slate-100 pb-5">
          <div>
            <h4 className="text-xl font-semibold text-slate-950">
              New audit project
            </h4>
            <p className="mt-2 text-sm leading-6 text-slate-500">
              Choose how you want to begin. Templates are optional.
            </p>
          </div>
          <span className="rounded-full bg-violet-50 px-3 py-1 text-xs font-semibold text-violet-700">
            Flexible setup
          </span>
        </div>

        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          <div className="rounded-2xl border-2 border-violet-200 bg-violet-50 p-5">
            <p className="text-sm font-semibold text-violet-800">
              Blank project
            </p>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              Start with an empty workspace and define your own audit structure.
            </p>
            <div
              data-tour-target="start-blank-button"
              className="mt-5 inline-flex rounded-xl bg-violet-600 px-4 py-2.5 text-sm font-semibold text-white"
            >
              Start blank
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <p className="text-sm font-semibold text-slate-950">
              Use a framework
            </p>
            <p className="mt-2 text-sm leading-6 text-slate-600">
              Pick SaaS, mobile, ecommerce, or accessibility when you want a
              head start.
            </p>
            <div data-tour-target="use-framework-button" className="mt-5 inline-flex rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-semibold text-slate-700">
              Browse frameworks
            </div>
          </div>
        </div>

        <div className="mt-6 rounded-2xl border border-slate-200 bg-slate-50 p-5">
          <FormLabel>Project name</FormLabel>
          <div className="mt-2 rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-900">
            Mobile App Audit
          </div>
        </div>
      </div>
    </div>
  );
}


function ClientsScreen() {
  return (
    <div className="h-full">
      <div className="flex items-start justify-between gap-6">
        <div>
          <h3 className="text-[28px] font-semibold tracking-[-0.04em] text-slate-950">
            Clients
          </h3>
          <p className="mt-2 text-base text-slate-500">
            Manage client workspaces, brand assets, projects, reports, and activity.
          </p>
        </div>
        <span className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-200">
          + New Client
        </span>
      </div>

      <div className="mt-7 grid grid-cols-4 gap-4">
        <DashboardStat value="6" label="Clients" description="Across your studio" />
        <DashboardStat value="18" label="Projects" description="Client and internal audits" />
        <DashboardStat value="41" label="Reports" description="Generated deliverables" />
        <DashboardStat value="86" label="Avg. health" description="Across active clients" />
      </div>

      <div className="mt-7 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <div className="grid grid-cols-[1.2fr_0.7fr_0.8fr_0.8fr_0.8fr] bg-slate-50 px-6 py-4 text-xs font-semibold uppercase tracking-wide text-slate-500">
          <span>Client</span>
          <span>Status</span>
          <span>Projects</span>
          <span>Reports</span>
          <span>Health</span>
        </div>
        <ClientTableRow name="Acme Retail" url="acmeretail.com" status="Active" projects="8" reports="12" health="88" />
        <ClientTableRow name="FinBank" url="finbank.com" status="Active" projects="6" reports="9" health="85" />
        <ClientTableRow name="HealthPlus" url="healthplus.com" status="Active" projects="4" reports="6" health="72" />
        <ClientTableRow name="Northpeak" url="northpeak.io" status="Active" projects="5" reports="8" health="79" />
      </div>
    </div>
  );
}

function FrameworksScreen() {
  return (
    <div className="h-full">
      <div className="flex items-start justify-between gap-6">
        <div>
          <h3 className="text-[28px] font-semibold tracking-[-0.04em] text-slate-950">
            Frameworks
          </h3>
          <p className="mt-2 text-base text-slate-500">
            Start with a reusable audit methodology or customize your own Studio framework.
          </p>
        </div>
        <span className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-200">
          + New Framework
        </span>
      </div>

      <div className="mt-7 grid gap-5 lg:grid-cols-2">
        <FrameworkCard
          targetKey="framework-card-saas"
          title="SaaS Onboarding Audit"
          label="Studio"
          description="Categories, journey stages, recommendations, and report defaults for product onboarding reviews."
          items={["Activation", "Empty states", "Forms", "Trust"]}
        />
        <FrameworkCard
          title="Mobile App Audit"
          label="Built-in"
          description="Review first launch, permissions, navigation, primary task flows, and mobile usability."
          items={["First launch", "Navigation", "Task flow", "Accessibility"]}
        />
        <FrameworkCard
          title="Accessibility Review"
          label="Studio"
          description="A reusable WCAG-focused audit setup with recommendation guidance and report defaults."
          items={["Keyboard", "Contrast", "Labels", "Semantics"]}
        />
        <FrameworkCard
          title="Ecommerce Checkout Audit"
          label="Built-in"
          description="Review product detail, cart, checkout, trust, error recovery, and purchase confidence."
          items={["Cart", "Payment", "Validation", "Confirmation"]}
        />
      </div>
    </div>
  );
}

function RecommendationLibraryScreen() {
  return (
    <ProjectWorkspaceShell activeTab="recommendations">
      <div className="flex items-start justify-between gap-6">
        <div>
          <h3 className="text-[28px] font-semibold tracking-[-0.04em] text-slate-950">
            Recommendations
          </h3>
          <p className="mt-2 text-base text-slate-500">
            Save reusable guidance and insert it into findings across client projects.
          </p>
        </div>
        <span className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-200">
          + New Recommendation
        </span>
      </div>

      <div className="mt-7 grid gap-4 lg:grid-cols-2">
        <RecommendationCard title="Improve form validation" category="Forms" used="Used 24 times" />
        <RecommendationCard title="Clarify empty states" category="UX Writing" used="Used 18 times" />
        <RecommendationCard title="Increase button contrast" category="Accessibility" used="Used 31 times" />
        <RecommendationCard title="Preserve progress after errors" category="Checkout" used="Used 12 times" />
      </div>
    </ProjectWorkspaceShell>
  );
}

function ProjectsScreen() {
  return (
    <div className="h-full">
      <div className="flex items-start justify-between gap-6">
        <div>
          <h3 className="text-[28px] font-semibold tracking-[-0.04em] text-slate-950">
            Projects
          </h3>
          <p className="mt-2 text-base text-slate-500">
            View existing audits, reopen active work, or create a new project.
          </p>
        </div>
        <span
          data-tour-target="new-project-button"
          className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-200"
        >
          + New Project
        </span>
      </div>

      <div className="mt-7 flex gap-2">
        <span className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-100">
          Active
        </span>
        <span className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 shadow-sm">
          Archived
        </span>
      </div>

      <div className="mt-7 overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <ProjectListRow
          targetKey="project-row-checkout"
          name="Checkout Optimization Audit"
          url="shopdemo.io/checkout"
          status="In Progress"
          date="Updated today"
          meta="Ecommerce • 8 findings • 2 journeys"
        />
        <ProjectListRow
          name="Mobile App Onboarding Audit"
          url="mobileapp.example"
          status="In Progress"
          date="Updated yesterday"
          meta="Mobile App • 5 findings • 1 journey"
        />
        <ProjectListRow
          name="Pricing Page Conversion Review"
          url="acme.io/pricing"
          status="Completed"
          date="Completed Jun 26"
          meta="SaaS • 3 findings • Report exported"
        />
        <ProjectListRow
          name="Accessibility Baseline Review"
          url="portal.acme.io"
          status="Archived"
          date="Archived Jun 20"
          meta="Accessibility • WCAG 2.2 checklist"
        />
      </div>
    </div>
  );
}

function ProjectOverviewScreen({
  projectName = "Mobile App Onboarding Audit",
  projectUrl = "mobileapp.example",
  existing = false,
}: {
  projectName?: string;
  projectUrl?: string;
  existing?: boolean;
}) {
  return (
    <ProjectWorkspaceShell activeTab="overview">
      <div className="flex items-start justify-between gap-6">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.18em] text-violet-600">
            Project workspace
          </p>
          <h3 className="mt-2 text-[28px] font-semibold tracking-[-0.04em] text-slate-950">
            {projectName}
          </h3>
          <p className="mt-2 text-base text-slate-500">
            {existing
              ? `${projectUrl} • Existing audit workspace with findings, journeys, evidence, and report progress.`
              : `${projectUrl} • New blank project workspace ready for findings, journeys, evidence, and reports.`}
          </p>
        </div>
        <span
          data-tour-target="new-finding-button"
          className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-200"
        >
          + New Finding
        </span>
      </div>

      <div className="mt-7 grid gap-4 lg:grid-cols-3">
        <DashboardStat
          value={existing ? "8" : "0"}
          label="Open findings"
          description={
            existing ? "Already documented" : "Start documenting issues"
          }
        />
        <DashboardStat
          value={existing ? "6" : "4"}
          label="Audit areas"
          description={existing ? "In review" : "Ready to review"}
        />
        <DashboardStat
          value={existing ? "2" : "1"}
          label="Journey maps"
          description={
            existing ? "Connected to findings" : "Ready to customize"
          }
        />
      </div>

      <div className="mt-7 grid gap-5 lg:grid-cols-[1fr_0.9fr]">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h4 className="text-xl font-semibold text-slate-950">
            Audit checklist
          </h4>
          <div className="mt-5 space-y-3 text-sm font-medium text-slate-600">
            <p>✓ First launch and permissions</p>
            <p>✓ Core navigation</p>
            <p>✓ Primary task flow</p>
            <p>✓ Error recovery and feedback</p>
          </div>
        </div>
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h4 className="text-xl font-semibold text-slate-950">
            Primary journey
          </h4>
          <p className="mt-2 text-sm text-slate-500">
            First launch → Browse → Complete task
          </p>
          <div className="mt-5 flex items-center gap-2 text-xs font-semibold text-slate-500">
            <span className="rounded-full bg-violet-50 px-3 py-1 text-violet-700">
              First launch
            </span>
            <span>→</span>
            <span className="rounded-full bg-slate-100 px-3 py-1">Browse</span>
            <span>→</span>
            <span className="rounded-full bg-slate-100 px-3 py-1">
              Task completion
            </span>
          </div>
        </div>
      </div>
    </ProjectWorkspaceShell>
  );
}

function NewFindingScreen() {
  return (
    <ProjectWorkspaceShell activeTab="findings">
      <div className="flex items-start justify-between gap-6">
        <div>
          <h3 className="text-[28px] font-semibold tracking-[-0.04em] text-slate-950">
            New finding
          </h3>
          <p className="mt-2 text-base text-slate-500">
            Capture the issue, impact, and recommendation.
          </p>
        </div>
        <span
          data-tour-target="add-evidence-button"
          className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-200"
        >
          Add Evidence
        </span>
      </div>

      <div className="mt-7 grid gap-5 lg:grid-cols-[1fr_0.9fr]">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <FormLabel>Finding title</FormLabel>
          <div className="mt-2 rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-900">
            Checkout error recovery is unclear
          </div>

          <div className="mt-5 grid gap-4 sm:grid-cols-2">
            <FormField label="Severity" value="High" />
            <FormField label="Journey" value="Primary Task Flow" />
            <FormField label="Impact" value="High" />
            <FormField label="Effort" value="Medium" />
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <FormLabel>Recommendation</FormLabel>
          <div className="mt-2 min-h-[142px] rounded-xl border border-slate-200 p-4 text-sm leading-6 text-slate-600">
            Make the recovery action more visible and preserve user progress
            when an error occurs.
          </div>
        </div>
      </div>
    </ProjectWorkspaceShell>
  );
}

function EvidenceScreen() {
  return (
    <ProjectWorkspaceShell activeTab="findings">
      <div className="flex items-start justify-between gap-6">
        <div>
          <h3 className="text-[28px] font-semibold tracking-[-0.04em] text-slate-950">
            Checkout error recovery is unclear
          </h3>
          <p className="mt-2 text-base text-slate-500">
            Add evidence so the issue is clear to stakeholders.
          </p>
        </div>
        <span data-tour-target="save-finding-button" className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-200">
          Save Finding
        </span>
      </div>

      <div className="mt-7 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h4 className="text-xl font-semibold text-slate-950">
          Evidence images
        </h4>
        <div className="mt-5 grid gap-5 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
            <p className="text-sm font-semibold text-slate-900">Image 1</p>
            <div className="mt-4 rounded-2xl border-2 border-dashed border-violet-200 bg-white px-5 py-10 text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-violet-50 text-lg font-semibold text-violet-700">
                +
              </div>
              <p className="mt-3 text-sm font-semibold text-slate-800">
                Drag and drop evidence
              </p>
              <p className="mt-1 text-xs text-slate-500">PNG, JPG, or WebP</p>
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-white p-5">
            <FormLabel>Image caption</FormLabel>
            <div className="mt-2 min-h-[154px] rounded-xl border border-slate-200 p-4 text-sm leading-6 text-slate-500">
              Checkout screen showing the error state after validation fails.
            </div>
          </div>
        </div>
      </div>
    </ProjectWorkspaceShell>
  );
}

function JourneyMapsScreen() {
  return (
    <ProjectWorkspaceShell activeTab="journeys">
      <div className="flex items-start justify-between gap-6">
        <div>
          <h3 className="text-[28px] font-semibold tracking-[-0.04em] text-slate-950">
            Journey Maps
          </h3>
          <p className="mt-2 text-base text-slate-500">
            Connect findings to steps in the user journey.
          </p>
        </div>
        <span className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-200">
          + Add Step
        </span>
      </div>

      <div className="mt-7 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <h4 className="text-xl font-semibold text-slate-950">
          Primary Task Flow
        </h4>
        <div className="mt-6 grid gap-4 lg:grid-cols-3">
          <JourneyStep title="First launch" status="Clear" />
          <JourneyStep title="Browse options" status="Needs review" />
          <JourneyStep
            title="Task completion"
            status="High-priority finding"
            active
          />
        </div>
        <div className="mt-6 rounded-2xl bg-violet-50 p-5">
          <p className="text-sm font-semibold text-violet-800">
            Linked finding
          </p>
          <p className="mt-2 text-sm text-slate-700">
            Checkout error recovery is unclear
          </p>
        </div>
      </div>
    </ProjectWorkspaceShell>
  );
}

function ReportsScreen({ exported = false }: { exported?: boolean }) {
  return (
    <ProjectWorkspaceShell activeTab="reports">
      <div className="flex items-start justify-between gap-6">
        <div>
          <h3 className="text-[28px] font-semibold tracking-[-0.04em] text-slate-950">
            Report Builder
          </h3>
          <p className="mt-2 text-base text-slate-500">
            Configure and export a client-ready UX audit report.
          </p>
        </div>
        <div className="flex gap-3">
          <span className="rounded-xl border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-900 shadow-sm">
            Preview
          </span>
          <span
            data-tour-target="export-pdf-button"
            className="rounded-xl bg-violet-600 px-5 py-3 text-sm font-semibold text-white shadow-md shadow-violet-200"
          >
            Export PDF
          </span>
        </div>
      </div>

      {exported && (
        <div className="mt-6 rounded-2xl border border-green-200 bg-green-50 px-5 py-4 text-sm font-semibold text-green-700">
          Report exported successfully.
        </div>
      )}

      <div className="mt-7 grid gap-5 lg:grid-cols-[0.85fr_1.15fr]">
        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h4 className="text-xl font-semibold text-slate-950">Template</h4>
          <div className="mt-5 space-y-3">
            <TemplateOption active label="Professional" />
            <TemplateOption label="Executive" />
            <TemplateOption label="Accessibility" />
          </div>

          <h4 className="mt-7 text-xl font-semibold text-slate-950">
            Sections
          </h4>
          <div className="mt-4 space-y-3 text-sm font-medium text-slate-600">
            <p>✓ Executive summary</p>
            <p>✓ Findings</p>
            <p>✓ Journey analysis</p>
            <p>✓ Recommendations</p>
          </div>
        </div>

        <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
          <h4 className="text-xl font-semibold text-slate-950">Preview</h4>
          <div className="mt-6 grid grid-cols-3 gap-4">
            <MiniReportPage title="Cover" />
            <MiniReportPage title="Summary" />
            <MiniReportPage title="Finding" />
          </div>
        </div>
      </div>
    </ProjectWorkspaceShell>
  );
}

function ProjectWorkspaceShell({
  activeTab,
  children,
}: {
  activeTab: "overview" | "findings" | "journeys" | "recommendations" | "reports";
  children: ReactNode;
}) {
  const tabs = [
    { id: "overview" as const, label: "Overview" },
    { id: "findings" as const, label: "Findings" },
    { id: "journeys" as const, label: "Journey Maps" },
    { id: "recommendations" as const, label: "Recommendations" },
    { id: "reports" as const, label: "Reports" },
  ];

  return (
    <div>
      <div className="mb-6 flex gap-2 border-b border-slate-200 pb-3">
        {tabs.map((tab) => (
          <span
            key={tab.id}
            data-tour-target={`tab-${tab.id}`}
            className={`rounded-xl px-4 py-2 text-sm font-semibold ${
              activeTab === tab.id
                ? "bg-violet-50 text-violet-700"
                : "text-slate-600"
            }`}
          >
            {tab.label}
          </span>
        ))}
      </div>
      {children}
    </div>
  );
}

function DashboardStat({
  value,
  label,
  description,
}: {
  value: string;
  label: string;
  description: string;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <p className="text-2xl font-semibold text-slate-950">{value}</p>
      <p className="mt-3 text-sm font-medium text-slate-900">{label}</p>
      <p className="mt-3 text-xs leading-5 text-slate-500">{description}</p>
    </div>
  );
}

function ProjectListRow({
  name,
  url,
  status,
  date,
  targetKey,
  meta,
}: {
  name: string;
  url: string;
  status: string;
  date: string;
  targetKey?: string;
  meta?: string;
}) {
  return (
    <div
      data-tour-target={targetKey}
      className="flex items-center justify-between border-b border-slate-100 px-6 py-5 last:border-b-0"
    >
      <div>
        <p className="text-base font-semibold text-slate-950">{name}</p>
        <p className="mt-1 text-sm text-slate-500">{url}</p>
        {meta && (
          <p className="mt-1 text-xs font-medium text-slate-400">{meta}</p>
        )}
      </div>
      <div className="text-right">
        <StatusPill status={status} />
        <p className="mt-2 text-sm text-slate-400">{date}</p>
      </div>
    </div>
  );
}


function ClientTableRow({
  name,
  url,
  status,
  projects,
  reports,
  health,
}: {
  name: string;
  url: string;
  status: string;
  projects: string;
  reports: string;
  health: string;
}) {
  return (
    <div className="grid grid-cols-[1.2fr_0.7fr_0.8fr_0.8fr_0.8fr] items-center border-b border-slate-100 px-6 py-4 text-sm last:border-b-0">
      <div>
        <p className="font-semibold text-slate-950">{name}</p>
        <p className="mt-1 text-xs text-slate-500">{url}</p>
      </div>
      <StatusPill status={status} />
      <p className="font-semibold text-slate-700">{projects}</p>
      <p className="font-semibold text-slate-700">{reports}</p>
      <span className="flex h-9 w-9 items-center justify-center rounded-full border border-green-200 bg-green-50 text-xs font-semibold text-green-700">
        {health}
      </span>
    </div>
  );
}

function FrameworkCard({
  title,
  label,
  description,
  items,
  targetKey,
}: {
  title: string;
  label: string;
  description: string;
  items: string[];
  targetKey?: string;
}) {
  return (
    <div
      data-tour-target={targetKey}
      className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.16em] text-violet-600">
            {label}
          </p>
          <h4 className="mt-3 text-xl font-semibold text-slate-950">{title}</h4>
        </div>
        <span className="rounded-full bg-violet-50 px-3 py-1 text-xs font-semibold text-violet-700">
          Use
        </span>
      </div>
      <p className="mt-4 text-sm leading-6 text-slate-600">{description}</p>
      <div className="mt-5 rounded-2xl bg-slate-50 p-4">
        <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
          Includes
        </p>
        <div className="mt-3 grid grid-cols-2 gap-2 text-sm text-slate-700">
          {items.map((item) => (
            <p key={item}>• {item}</p>
          ))}
        </div>
      </div>
    </div>
  );
}

function RecommendationCard({
  title,
  category,
  used,
}: {
  title: string;
  category: string;
  used: string;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h4 className="text-base font-semibold text-slate-950">{title}</h4>
          <p className="mt-2 text-sm text-slate-500">{used}</p>
        </div>
        <span className="rounded-full bg-violet-50 px-3 py-1 text-xs font-semibold text-violet-700">
          {category}
        </span>
      </div>
      <p className="mt-4 text-sm leading-6 text-slate-600">
        Reusable guidance that can be inserted into finding recommendations.
      </p>
    </div>
  );
}

function ProjectTableRow({
  name,
  url,
  type,
  findings,
  status,
}: {
  name: string;
  url: string;
  type: string;
  findings: string;
  status: string;
}) {
  return (
    <div className="grid grid-cols-[1.4fr_0.9fr_0.8fr_0.9fr] items-center border-b border-slate-100 px-6 py-4 text-sm last:border-b-0">
      <div>
        <p className="font-semibold text-slate-950">{name}</p>
        <p className="mt-1 text-xs text-slate-500">{url}</p>
      </div>
      <span className="w-fit rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-700">
        {type}
      </span>
      <span className="text-slate-600">{findings}</span>
      <StatusPill status={status} />
    </div>
  );
}

function JourneyStep({
  title,
  status,
  active = false,
}: {
  title: string;
  status: string;
  active?: boolean;
}) {
  return (
    <div
      className={`rounded-2xl border p-5 ${active ? "border-violet-200 bg-violet-50" : "border-slate-200 bg-slate-50"}`}
    >
      <p className="text-sm font-semibold text-slate-950">{title}</p>
      <p
        className={`mt-2 text-xs font-semibold ${active ? "text-violet-700" : "text-slate-500"}`}
      >
        {status}
      </p>
    </div>
  );
}

function FormLabel({ children }: { children: ReactNode }) {
  return (
    <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">
      {children}
    </p>
  );
}

function FormField({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <FormLabel>{label}</FormLabel>
      <div className="mt-2 rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-800">
        {value}
      </div>
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const tone =
    status === "Completed" || status === "Ready"
      ? "bg-green-100 text-green-700"
      : status === "Archived"
        ? "bg-slate-100 text-slate-600"
        : "bg-blue-100 text-blue-700";

  return (
    <span
      className={`w-fit rounded-full px-3 py-1 text-xs font-semibold ${tone}`}
    >
      {status}
    </span>
  );
}

function ProgressRow({
  label,
  value,
  width,
  color = "bg-violet-500",
}: {
  label: string;
  value: string;
  width: string;
  color?: string;
}) {
  return (
    <div>
      <div className="flex items-center justify-between text-sm font-semibold text-slate-600">
        <span>{label}</span>
        <span>{value}</span>
      </div>
      <div className="mt-2 h-2 rounded-full bg-slate-100">
        <div className={`h-2 rounded-full ${color}`} style={{ width }} />
      </div>
    </div>
  );
}

function BarRow({
  title,
  subtitle,
  value,
  width,
}: {
  title: string;
  subtitle: string;
  value: string;
  width: string;
}) {
  return (
    <div>
      <div className="flex items-end justify-between gap-3 text-sm font-semibold text-slate-700">
        <div>
          <p>{title}</p>
          <p className="mt-1 text-xs font-medium text-slate-500">{subtitle}</p>
        </div>
        <span>{value}</span>
      </div>
      <div className="mt-2 h-2 rounded-full bg-slate-100">
        <div className="h-2 rounded-full bg-violet-500" style={{ width }} />
      </div>
    </div>
  );
}

function TemplateOption({
  label,
  active = false,
}: {
  label: string;
  active?: boolean;
}) {
  return (
    <div
      className={`rounded-xl border px-4 py-3 text-sm font-semibold ${
        active
          ? "border-violet-200 bg-violet-50 text-violet-700"
          : "border-slate-200 bg-white text-slate-700"
      }`}
    >
      {label}
    </div>
  );
}

function MiniReportPage({ title }: { title: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
      <p className="text-[10px] font-semibold uppercase tracking-[0.14em] text-violet-600">
        {title}
      </p>
      <div className="mt-4 h-3 w-16 rounded-full bg-slate-950" />
      <div className="mt-5 space-y-2">
        <div className="h-2 rounded-full bg-slate-200" />
        <div className="h-2 w-3/4 rounded-full bg-slate-200" />
        <div className="h-2 w-1/2 rounded-full bg-slate-200" />
      </div>
      <div className="mt-6 h-16 rounded-xl bg-white" />
    </div>
  );
}
