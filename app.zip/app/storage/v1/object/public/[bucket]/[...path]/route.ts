import { fileKey, store } from "@/lib/mockdb/store";

export const dynamic = "force-dynamic";

// Serves files uploaded to the prototype's in-memory storage, using the same
// URL shape as Supabase public storage.
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ bucket: string; path: string[] }> }
) {
  const { bucket, path } = await params;
  const file = store.files.get(fileKey(bucket, path.join("/")));

  if (!file) return new Response("Not found", { status: 404 });

  return new Response(file.data as unknown as BodyInit, {
    headers: {
      "Content-Type": file.contentType,
      "Cache-Control": "no-store",
    },
  });
}
