export type Finding = {
  id: string;
  user_id: string;
  project_id: string;
  title: string | null;
  description?: string | null;
  severity: string | null;
  impact: string | null;
  effort: string | null;
  status: string | null;
  recommendation?: string | null;
  category?: string | null;
  recommendation_source?: "library" | "framework" | string | null;
  saved_recommendation_id?: string | null;
  framework_recommendation_id?: string | null;
  linked_recommendation_title?: string | null;
  created_at: string;
  updated_at?: string | null;
};
